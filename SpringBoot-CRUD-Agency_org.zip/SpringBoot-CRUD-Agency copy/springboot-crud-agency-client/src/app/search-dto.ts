export class SearchDto {
  wishToPay: number;
  minNoOfBeds: number;
  minBedArea: number;
  minNoOfBaths: number;
  minBathArea: number;
  minTotalArea: number;  
}